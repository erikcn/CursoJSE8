public class Karen{
	public String nombre = "KAren" ;
	
}