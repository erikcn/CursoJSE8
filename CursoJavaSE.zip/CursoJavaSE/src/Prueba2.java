//import otros;

public class Prueba2{
	
	public static void main(String[] args) {
		Karen karen = new Karen();

		System.out.println(karen.nombre);
		
	}

}

