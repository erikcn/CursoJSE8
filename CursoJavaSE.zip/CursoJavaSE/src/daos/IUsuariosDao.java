package daos;

public interface IUsuariosDao {
	
	public String register(String usuario, String password);

}
