import java.util.Scanner;

public class Ciclos {
	
	public static void main(String[] args ) {
		
		//Scanner s = new Scanner(System.in);
		//int num = s.nextInt();
		
		int numeros[] = new int[5];
		numeros[0]=6;
		
		System.out.println(numeros[0]);
	}

}
