//Imports
import java.lang.*;

//Definicion de la clase
public class Prueba{
	//Definicion de capos (variables)
	int numero;

	//Definición de constructor
	int Prueba(){

	}

	//Definición de metodos (funciones)
	public int suma (int a, int b){
		return a + b;
	}

	public static void main(String[] args) {		
	}

}