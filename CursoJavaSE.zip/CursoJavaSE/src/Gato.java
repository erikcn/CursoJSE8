
public class Gato extends Felino  {

}
