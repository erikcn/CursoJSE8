package abstracto;

public class ListEjemplo {

}
