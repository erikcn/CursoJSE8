package services.interfaces;

public interface IUsuarioService {
	public String register(String usuario, String password);

}
