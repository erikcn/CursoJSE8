
public class Felino {
	public String maullido;

	public String getMaullido() {
		return maullido;
	}

	public void setMaullido(String maullido) {
		this.maullido = maullido;
	}
	
	public void maullar () {
		System.out.println(maullido);
	}
	
}
