//Imports
import java.lang.*;

//Definicion de la clase
public class Prueba{
	//Definicion de capos (variables)
	
	//comentario de linea
	
	/*
	*comentario de bloque o multilinea
	*/

	//Javadoc   Java Documentation 
	/**
	@param
	@author
	*/

	public static void main(String[] args) {
		System.out.println("Hola Erik ...");
		
	}

}

