
public class Main {

	public static void main(String[] args) {
		Gato salem = new Gato();
		salem.setMaullido("GUAUUU");
		salem.maullar();
		
		Gato cucho = new Gato();
		cucho.setMaullido("MIAUCUCHO");
		cucho.maullar();
		
		
		//System.out.println(salem.getMaullido());

	}

	
	
	
}
