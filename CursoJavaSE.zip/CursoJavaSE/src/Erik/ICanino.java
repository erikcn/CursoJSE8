package Erik;

public interface ICanino {
	public static final int PATAS=4;

	
	public void setRaza(String raza);
	
	public String getRaza();
	
	public String ladrar();
}
