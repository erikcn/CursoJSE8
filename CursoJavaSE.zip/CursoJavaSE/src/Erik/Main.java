package Erik;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Perro p = new Perro();
		
		System.out.println(p.ladrar());
		//System.out.println(p.getRaza());
		
		
Lobo l = new Lobo();
		
		System.out.println(l.ladrar());
		//System.out.println(l.getRaza());

	}

}
