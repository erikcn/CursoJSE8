package Lambdas;

public interface Operacion2 {
	public void hola();

}
